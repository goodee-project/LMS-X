package gd.fintech.lms.vo;

import lombok.Data;

@Data
public class LectureAndClassRegistrationAndSubject {
	public Lecture lecture;
	public ClassRegistration classRegistration;
	public Subject subject;
}
