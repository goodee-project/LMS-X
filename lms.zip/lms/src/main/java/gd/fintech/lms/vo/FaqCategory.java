package gd.fintech.lms.vo;

import lombok.Data;

// 자주 묻는 질문(FAQ) 카테고리 Vo

@Data
public class FaqCategory {
	private String		faqCategory;	// FAQ 카테고리
}
