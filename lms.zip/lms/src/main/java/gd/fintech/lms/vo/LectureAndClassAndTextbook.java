package gd.fintech.lms.vo;

import lombok.Data;

@Data
public class LectureAndClassAndTextbook {
	public Lecture lecture;
	public Classroom classroom;
	public Textbook textbook;
}
